function yeti() {
    alert("Roarrrr! Game Over");
}

function random() {
    penguins = ["../images/penguin_1.png", "../images/penguin_2.png",
        "../images/penguin_3.png", "../images/penguin_4.png", "../images/penguin_5.png", "../images/penguin_6.png",
        "../images/penguin_7.png", "../images/penguin_8.png", "../images/yeti.png"];

    var i = 0,
        j = 0,
        temp = null;
    for (i = penguins.length - 1; i > 0; i -= 1) {
        j = Math.floor(Math.random() * (i + 1));
        temp = penguins[i];
        penguins[i] = penguins[j];
        penguins[j] = temp;
    }
    // for (i = 0; i < penguins.length; i++) {
    //     var img = penguins[i];
    //     var imgStr = '<img src="' + img + '" alt="">';
    //     document.write(imgStr);
    //     img.src = img;
    // }
}

function displayImage(i) {
    if(penguins[i]!="../images/yeti.png")
    {
        document.getElementById("penguin" + i).src = penguins[i];
    }
    else
    {
        document.getElementById("penguin" + i).src = penguins[i];
        alert("ROOOAAAAARRRRR!"+"\n"+"Start a new new Game");
        window.location.reload();
    }
}